package weather_project;

public class Interface{
  
  public Interface(){
 
  }

  public void afficheInterface(int n_jours, double temperatures[], Ville ville_demande){
	  int i;
	  
	  ville_demande.afficheVille();

	  
	  System.out.print("              +-----+");
	  for (i = 0; i < n_jours - 1; i++ ) {
			System.out.print("-----+");
	  }
	  System.out.println("");
	  
	  
	  System.out.print("              | J+");
	  System.out.print(0);
	  System.out.print(" |");

	  for (i = 1; i < n_jours; i++ ) {
		  	System.out.print(" J+");
			System.out.print(i);
			System.out.print(" |");
	  }
	  System.out.println("");

	  
	  System.out.print("+-------------+-----+");

	  for (i = 0; i < n_jours - 1; i++ ) {
			System.out.print("-----+");
	  }
	  System.out.println("");

	  System.out.print("|             |");
	  for (i = 0; i < n_jours; i++ ) {
		  System.out.print(" ");
		  if ((int)Math.floor(temperatures[i])/10 == 0)
			  System.out.print(" ");
		  System.out.print((int)Math.floor(temperatures[i]));
		  System.out.print("° |");
	  }
	  System.out.println("");

	  
	  System.out.print("+-------------+-----+");
	  for (i = 0; i < n_jours - 1; i++ ) {
			System.out.print("-----+");
	  }
	  System.out.println("");

  }

}