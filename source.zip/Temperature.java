package weather_project;

public class Temperature extends ElementMeteo{
  private int temperature;

  public Temperature(){
	super();
    this.temperature = 0;
    //this.setTemperature(ville, jour);
  }

  public int getTemperature() {	  	
		return temperature;
  }
  
  public void setTemperature(int temp) {
	  this.temperature = temp;
  }

 
}