package weather_project;
public class ElementMeteo{

  public ElementMeteo(){
	  
  }

}