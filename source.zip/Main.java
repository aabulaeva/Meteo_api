package weather_project;

import java.io.IOException;


public class Main {
	public static void main(String[] args) throws IOException {
		String ville= "";
		int jour = 0;
	 
		// Récupération informations ligne de commande
		for (int i=0; i<args.length; i++)
	 	{
	 	    if ("-l".equals(args[i]))
	 	   {
	 	       ville = args[i+1];
	 	   }
	 	   if ("-j".equals(args[i]))
	 	   {
	 	       jour =Integer.parseInt(args[i+1]);
	 	   }
	 	}

	 	
		// Récupération informations sur internet
	 	Connection a = new Connection(jour,ville);
	 	double temperatures[] = a.httprequest();
		Ville ville_demande = new Ville(ville);

		// Affichage	
	    Interface i = new Interface();
	    i.afficheInterface(jour, temperatures, ville_demande);
	}


}
