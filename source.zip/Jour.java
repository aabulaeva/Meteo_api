package weather_project;

public class Jour {
  private int jour;

  public Jour(int jour){
    this.jour = jour;
  }

  public int getJour() {
    return this.jour;
  }

}